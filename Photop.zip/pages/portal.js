wireframes.portal = `
	<div style="display:flex;height:100%;">
		<div class="portalSidebar">
	 		<button class="portalSidebarButton">Bots</button>
		 	<button class="portalSidebarButton">Documentation</button>
	 	</div>
	
	 	<div class="portalContent"></div>
	</div>
`;

pages.portal = function() {
	app.style.width = "1038px";
}